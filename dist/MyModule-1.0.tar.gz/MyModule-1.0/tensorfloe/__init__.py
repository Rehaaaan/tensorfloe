# tensorfloe/__init__.py

from . import spam
from . import sentiment
from . import gender
from . import pos
from . import word2vec
from . import skipgram
from . import chatbot
from . import summary
from . import transformer
from . import latent

